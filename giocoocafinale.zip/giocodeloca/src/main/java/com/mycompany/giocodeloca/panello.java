    /*
    * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
    * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
    */
    package com.mycompany.giocodeloca;


    import javax.swing.*;
    import javax.swing.border.Border;
    import java.awt.*;
    import java.awt.event.ActionEvent;
    import java.awt.event.ActionListener;
    import java.util.ArrayList;


    public class panello extends JPanel implements ActionListener{

    public static final int GIOCATORI = 4;
    private ImageIcon sfondo;
    private Tabellone tabellone;
    private ArrayList<Pedina> pedine;
    private Domande quesiti;
    JButton b1;
    dadi dado1;
    dadi dado;
    JTextArea area;
    JLabel giocatoreAttuale;
    private String domanda;
    Border border;
    private final Timer disegno;
    private int giocatoreAttualeIndex=0;

    public panello() {
        sfondo= new ImageIcon("immagini/tavolo.jpg");
        this.setBackground(new Color(225, 193, 110));
        tabellone = new Tabellone();
        quesiti = new Domande();
        pedine = new ArrayList<>(GIOCATORI);
        pedine.add(new Pedina(new Point(110, 395),new ImageIcon ("immagini/giocatore1.png"), new Cella(new Point(110, 395),"NORMALE", 0)));
        pedine.add(new Pedina(new Point(55, 385),new ImageIcon ("immagini/giocatore2.png"), new Cella(new Point(55, 385),"NORMALE", 0)));
        pedine.add(new Pedina(new Point(55, 415),new ImageIcon ("immagini/giocatore3.png"), new Cella(new Point(55, 415),"NORMALE", 0)));
        pedine.add(new Pedina(new Point(110, 425),new ImageIcon ("immagini/giocatore4.png"), new Cella(new Point(110, 425),"NORMALE", 0)));
        this.setLayout(null);
        dado1 = new dadi();
        dado = new dadi();
        b1 = new JButton("LANCIA");
        this.add(b1);
        b1.setBounds( 780, 300 , 120, 30);
        b1.addActionListener(this);
        giocatoreAttuale= new JLabel();
        giocatoreAttuale.setBounds( 100, 580 , 400, 300);
        giocatoreAttuale.setFont(new Font("Arial", Font.BOLD, 32));
        giocatoreAttuale.setForeground(Color.GREEN);
        giocatoreAttuale.setText("Turno Giocatore : 1");
        
        
        area = new JTextArea();
        area.setFont(new Font("Arial", Font.BOLD, 16));
        area.setText("\nGiocatore 1: 0, \nGiocatore 2: 0,\nGiocatore 3: 0, \nGiocatore 4: 0, ");
        area.setForeground(Color.BLACK);
        area.setBackground(new Color(225, 193, 110));
        area.setBounds(600, 580, 350 , 330 );
        area.setFocusable(false);
        area.setVisible(true);
        area.setEditable(false);
        area.setLineWrap(true);
        border = BorderFactory.createLineBorder(new Color(165, 42, 42) , 2);
        area.setBorder(border);
        giocatoreAttuale.setBorder(border);
        this.setLayout(null);
        this.add(area);
        this.add(giocatoreAttuale);
        b1.setBounds( 780 , 379 , 120, 30);
        disegno=new Timer(16,e -> repaint());
        disegno.start();

    }


    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b1) {
            dado1.generazione();
            System.out.println(""+ dado1.getFaccia());
            dado.generazione();
            System.out.println(""+ dado.getFaccia());
            iniziogioco();

        }
    }



    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(sfondo.getImage(), 0, 0, null);
        g.drawImage(dado.getImmagine().getImage(), 850, 100, this);
        g.drawImage(dado1.getImmagine().getImage(), 710 , 100, this);
        for(int i=0;i<pedine.size();i++){
            g.drawImage(pedine.get(i).getAsset().getImage() ,(int) pedine.get(i).getPosizione().getX(),(int) pedine.get(i).getPosizione().getY(), this);
        }
    }

    public void iniziogioco(){
        int scelta;
        Pedina giocatore;
        giocatore=pedine.get(giocatoreAttualeIndex);
        int sommadadi = dado.getFaccia()+dado1.getFaccia();


        int nuovaPosizione = (giocatore.getCasella().getNumero() + sommadadi);


        muoviti(giocatore, giocatore.getCasella().getNumero() , sommadadi);
        

        while(giocatore.getCasella().getTipo().equals("RADDOPPIO") && giocatore.getCasella().getNumero()+sommadadi<63) {
            area.setText("");
            for(int i=0;i<pedine.size();i++){
                area.append("Giocatore "+(i+1)+": "+(pedine.get(i).getCasella().getNumero()+1)+"\n");
            }
            area.append("Giocatore "+(giocatoreAttualeIndex+1)+" è caduto in una cella radoppio");
            do {
                domanda = quesiti.generaDomanada();
                scelta = JOptionPane.showOptionDialog(null, domanda , "Quesito", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, new String[]{"Vero", "Falso"}, null);
            } while (scelta == -1);

            muoviti(giocatore, giocatore.getCasella().getNumero(), sommadadi);
        
        
        }


        switch(giocatore.getCasella().getTipo()){
            case "PRIGIONE":
                area.setText("");
                for(int i=0;i<pedine.size();i++){
                    area.append("Giocatore "+(i+1)+": "+(pedine.get(i).getCasella().getNumero()+1)+"\n");
                }
                area.append("Giocatore "+(giocatoreAttualeIndex+1)+" è caduto nella casella PRIGIONE");
                do {
                    domanda = quesiti.generaDomanada();
                    scelta = JOptionPane.showOptionDialog(null, domanda , "Quesito", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, new String[]{"Vero", "Falso"}, null);
                } while (scelta == -1);    
                for (Pedina altroGiocatore : pedine) {
                    if (altroGiocatore != giocatore && altroGiocatore.getCasella().getNumero() == giocatore.getCasella().getNumero()) {
                        // Un altro giocatore è già imprigionato, quindi il giocatore attuale rimane imprigionato
                        altroGiocatore.setInPrigione(false);
                        giocatore.setInPrigione(true);

                    }
                    else{
                        giocatore.setInPrigione(true);
                    }
                }
                break;

            case "SOSTA":
                area.setText("");
                for(int i=0;i<pedine.size();i++){
                    area.append("Giocatore "+(i+1)+": "+(pedine.get(i).getCasella().getNumero()+1)+"\n");
                }
                area.append("Giocatore "+(giocatoreAttualeIndex+1)+" deve aspettare 3 turni ");
                do {
                    domanda = quesiti.generaDomanada();
                    scelta = JOptionPane.showOptionDialog(null, domanda , "Quesito", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, new String[]{"Vero", "Falso"}, null);
                } while (scelta == -1);                
                giocatore.setTurniSaltati(3);
                
                break;

            case "LABIRINTO":
                System.out.println("DENTRO");
                area.setText("");
                for(int i=0;i<pedine.size();i++){
                    area.append("Giocatore "+(i+1)+": "+(pedine.get(i).getCasella().getNumero()+1)+"\n");
                }
                area.append("Giocatore "+(giocatoreAttualeIndex+1)+" è caduto nella casella LABIRINTO e deve tornare nella cella 39 ");
                do {
                    domanda = quesiti.generaDomanada();
                    scelta = JOptionPane.showOptionDialog(null, domanda , "Quesito", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, new String[]{"Vero", "Falso"}, null);
                } while (scelta == -1);
                giocatore.setCasella(tabellone.getPosCelle().get(38));
                giocatore.setPosizione(tabellone.getPosCelle().get(giocatore.getCasella().getNumero()).getPosition());
                area.setText("");
                
                break;
            case "SCHELETRO":
                System.out.println("DENTRO");
                area.setText("");
                for(int i=0;i<pedine.size();i++){
                    area.append("Giocatore "+(i+1)+": "+(pedine.get(i).getCasella().getNumero()+1)+"\n");
                }
                area.append("Giocatore "+(giocatoreAttualeIndex+1)+" è caduto nella casella scheletro ed è tornato nella 1 casella ");
                do {
                    domanda = quesiti.generaDomanada();
                    scelta = JOptionPane.showOptionDialog(null, domanda , "Quesito", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, new String[]{"Vero", "Falso"}, null);
                } while (scelta == -1);
                giocatore.setCasella(tabellone.getPosCelle().get(0));
                giocatore.setPosizione(tabellone.getPosCelle().get(giocatore.getCasella().getNumero()).getPosition());
                break;
            case "VITTORIA":
                b1.setEnabled(false);
                        area.setText("");
                for(int i=0;i<pedine.size();i++){
                    area.append("Giocatore "+(i+1)+": "+(pedine.get(i).getCasella().getNumero()+1)+"\n");
                }
                giocatoreAttuale.setText("Ha vinto Giocatore : "+(giocatoreAttualeIndex+1)+"");
                return;
        }
        
        avanzaturno();
        
        switch(giocatoreAttualeIndex){
            case 0:
                giocatoreAttuale.setForeground(Color.GREEN);
                break;
        
            case 1:
                giocatoreAttuale.setForeground(Color.BLUE);
                break;    
        
            case 2:
                giocatoreAttuale.setForeground(Color.RED);
                break;    
        
            case 3:
                giocatoreAttuale.setForeground(Color.YELLOW);
                break; 
        
        }
        giocatoreAttuale.setText("Turno Giocatore : "+(giocatoreAttualeIndex+1)+"");
        area.setText("");
        for(int i=0;i<pedine.size();i++){
            area.append("Giocatore "+(i+1)+": "+(pedine.get(i).getCasella().getNumero()+1)+"\n");
        }
    }


    private void avanzaturno() {
        // Incrementa l'indice del giocatore attuale
        do{
            giocatoreAttualeIndex = (giocatoreAttualeIndex + 1) % GIOCATORI;
            if(pedine.get(giocatoreAttualeIndex).getTurniSaltati()>0){
                pedine.get(giocatoreAttualeIndex).decrementaTurniSaltati();
            }
        }while(!pedine.get(giocatoreAttualeIndex).canmove());
    }

        
    private void muoviti(Pedina pedine, int cellaAttuale, int sommadadi){
        int nuovaPosizione = cellaAttuale + sommadadi;
        if(nuovaPosizione>tabellone.getPosCelle().size()){
            nuovaPosizione = cellaAttuale- sommadadi;
        }
            pedine.setCasella(tabellone.getPosCelle().get(nuovaPosizione));
            pedine.setPosizione(tabellone.getPosCelle().get(nuovaPosizione).getPosition());   

            
    }
}


