/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.mycompany.giocodeloca;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class frame extends JFrame {
    
    panello panel;
    
    frame(){
        this.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
        this.setTitle("gioco dell' oca");
        this.setSize(1000, 1000);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        ImageIcon logo = new ImageIcon("immagini/oca.jpg");
        this.setIconImage(logo.getImage());         
        this.setLayout(null);
        panel = new panello();
        panel.setBounds(0, 0, 1000, 1000); // Imposta posizione e dimensioni
        this.add(panel);
        this.setVisible(true);
        
    }
    
    
    
    
}
