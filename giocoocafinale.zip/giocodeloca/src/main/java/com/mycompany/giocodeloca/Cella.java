package com.mycompany.giocodeloca;

import java.awt.Point;
import javax.swing.text.Position;

public class Cella {
    private Point position;
    private int numero;
    private String tipo;

    public Cella(Point position, String tipo, int numero) {
    
        this.position=position;
        this.tipo=tipo;
        this.numero=numero-1;
    }
 
    
    public Point getPosition() {
        return position;
    }

    public int getNumero() {
        return numero;
    }

    public String getTipo() {
        return tipo;
    }

    public void setPosition(Point position) {
        this.position = position;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    
}
