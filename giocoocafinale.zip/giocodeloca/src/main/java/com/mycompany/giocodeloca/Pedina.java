/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.giocodeloca;

import java.awt.Point;
import javax.swing.*;
import java.awt.*;


public class Pedina {
    
    private Point posizione;
    private ImageIcon asset;
    private Cella casella ;
    private int turniSaltati;
    private boolean inPrigione; 

    
    
    public Pedina(Point posizione, ImageIcon asset, Cella casella) {
        this.posizione = posizione;
        this.asset = asset;
        this.casella= casella;
        inPrigione=false;
    }
    
    
    

    public void setPosizione(Point posizione) {
        this.posizione = posizione;
    }

    public void setAsset(ImageIcon asset) {
        this.asset = asset;
    }

    public Point getPosizione() {
        return posizione;
    }

    public ImageIcon getAsset() {
        return asset;
    }

    public Cella getCasella() {
        return casella;
    }

    public void setCasella(Cella casella) {
        this.casella = casella;
    }
    

    public int getTurniSaltati() {
        return turniSaltati;
    }

    public void setTurniSaltati(int turniSaltati) {
        this.turniSaltati = turniSaltati;
    }

    public void decrementaTurniSaltati() {
        if (turniSaltati > 0) {
            turniSaltati--;
        }
    }

    public boolean getInPrigione() {
        return inPrigione;
    }

    public void setInPrigione(boolean inPrigione) {
        this.inPrigione = inPrigione;
    }


    public boolean canmove(){
        return !inPrigione && turniSaltati==0;
    }


}
