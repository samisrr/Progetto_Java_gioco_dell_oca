/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.giocodeloca;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;

/**
 *
 * @author simni
 */
public class Domande {
    private final int  NUM_QUESITI=15;
    private String[] quesiti;
    private final Random random;
   
    
    public Domande(){
        random =new Random();
        quesiti = new String[NUM_QUESITI];
        leggiDomande();
    }
    
    
    
    public void leggiDomande(){
        String filePath = "domande/0.txt";
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            int i=0;
            while ((line = br.readLine()) != null ) {
                quesiti[i]=line;
                System.out.println(quesiti[i]);
                i++;
            }
        }    
        catch (IOException e) {
            e.printStackTrace();
        }    
        
    }
    
    
    public String generaDomanada(){
        String quesito;
        int generazione;
        generazione= random.nextInt(0,NUM_QUESITI);
        quesito=quesiti[generazione];
        return quesito;
    }
        
        
}
