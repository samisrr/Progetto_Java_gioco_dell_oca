package com.mycompany.giocodeloca;

import java.awt.*;
import java.util.ArrayList;

public class Tabellone {
    private ArrayList<Cella> posCelle;
    
    
    public Tabellone() {
        posCelle = new ArrayList<>();
        initCelle();
    }

    private void initCelle() {
        posCelle.add(new Cella(new Point(190, 402), "NORMALE", 1));
        posCelle.add(new Cella(new Point(224, 402), "NORMALE", 2));
        posCelle.add(new Cella(new Point(260, 402), "NORMALE", 3));
        posCelle.add(new Cella(new Point(300, 402), "NORMALE", 4));
        posCelle.add(new Cella(new Point(345, 402), "RADDOPPIO", 5));
        posCelle.add(new Cella(new Point(390, 402), "RADDOPPIO", 6));
        posCelle.add(new Cella(new Point(430, 402), "NORMALE", 7));
        posCelle.add(new Cella(new Point(470, 395), "NORMALE", 8));
        posCelle.add(new Cella(new Point(520, 385), "RADDOPPIO", 9));
        posCelle.add(new Cella(new Point(555, 350), "NORMALE", 10));
        posCelle.add(new Cella(new Point(580, 320), "NORMALE", 11));
        posCelle.add(new Cella(new Point(595, 285), "NORMALE", 12));
        posCelle.add(new Cella(new Point(605, 255), "NORMALE", 13));
        posCelle.add(new Cella(new Point(610, 210), "RADDOPPIO", 14));
        posCelle.add(new Cella(new Point(605, 170), "NORMALE", 15));
        posCelle.add(new Cella(new Point(590, 130), "NORMALE", 16));
        posCelle.add(new Cella(new Point(570, 100), "NORMALE", 17));
        posCelle.add(new Cella(new Point(535, 60), "RADDOPPIO", 18));
        posCelle.add(new Cella(new Point(480, 30), "SOSTA", 19));
        posCelle.add(new Cella(new Point(425, 30), "NORMALE", 20));
        posCelle.add(new Cella(new Point(385, 30), "NORMALE", 21));
        posCelle.add(new Cella(new Point(350, 30), "NORMALE", 22));
        posCelle.add(new Cella(new Point(300, 30), "RADDOPPIO", 23));
        posCelle.add(new Cella(new Point(255, 30), "NORMALE", 24));
        posCelle.add(new Cella(new Point(220, 30), "NORMALE", 25));
        posCelle.add(new Cella(new Point(175, 30), "RADDOPPIO", 26));
        posCelle.add(new Cella(new Point(140, 45), "RADDOPPIO", 27));
        posCelle.add(new Cella(new Point(105, 65), "NORMALE", 28));
        posCelle.add(new Cella(new Point(80, 100), "NORMALE", 29));
        posCelle.add(new Cella(new Point(65, 135), "NORMALE", 30));
        posCelle.add(new Cella(new Point(55, 170), "PRIGIONE", 31));
        posCelle.add(new Cella(new Point(60, 220), "RADDOPPIO", 32));
        posCelle.add(new Cella(new Point(75, 250), "NORMALE", 33));
        posCelle.add(new Cella(new Point(90, 290), "NORMALE", 34));
        posCelle.add(new Cella(new Point(115, 315), "NORMALE", 35));
        posCelle.add(new Cella(new Point(150, 330), "RADDOPPIO", 36));
        posCelle.add(new Cella(new Point(190, 335), "NORMALE", 37));
        posCelle.add(new Cella(new Point(225, 335), "NORMALE", 38));
        posCelle.add(new Cella(new Point(265, 335), "NORMALE", 39));
        posCelle.add(new Cella(new Point(305, 335), "NORMALE", 40));
        posCelle.add(new Cella(new Point(350, 335), "RADDOPPIO", 41));
        posCelle.add(new Cella(new Point(395, 335), "LABIRINTO", 42));
        posCelle.add(new Cella(new Point(435, 335), "NORMALE", 43));
        posCelle.add(new Cella(new Point(470, 325), "NORMALE", 44));
        posCelle.add(new Cella(new Point(510, 305), "RADDOPPIO", 45));
        posCelle.add(new Cella(new Point(535, 270), "NORMALE", 46));
        posCelle.add(new Cella(new Point(545, 235), "NORMALE", 47));
        posCelle.add(new Cella(new Point(545, 200), "NORMALE", 48));
        posCelle.add(new Cella(new Point(535, 165), "NORMALE", 49));
        posCelle.add(new Cella(new Point(510, 120), "RADDOPPIO", 50));
        posCelle.add(new Cella(new Point(465, 100), "NORMALE", 51));
        posCelle.add(new Cella(new Point(410, 100), "PRIGIONE", 52));
        posCelle.add(new Cella(new Point(350, 100), "RADDOPPIO", 53));
        posCelle.add(new Cella(new Point(300, 100), "RADDOPPIO", 54));
        posCelle.add(new Cella(new Point(255, 100), "NORMALE", 55));
        posCelle.add(new Cella(new Point(220, 100), "NORMALE", 56));
        posCelle.add(new Cella(new Point(180, 100), "NORMALE", 57));
        posCelle.add(new Cella(new Point(130, 130), "SCHELETRO", 58));
        posCelle.add(new Cella(new Point(125, 190), "RADDOPPIO", 59));
        posCelle.add(new Cella(new Point(130, 235), "NORMALE", 60));
        posCelle.add(new Cella(new Point(155, 260), "NORMALE", 61));
        posCelle.add(new Cella(new Point(190, 265), "NORMALE", 62));
        posCelle.add(new Cella(new Point(220, 190), "VITTORIA", 63));

    }

    public ArrayList<Cella> getPosCelle (){
        return posCelle;
    }

    
    
    
}
