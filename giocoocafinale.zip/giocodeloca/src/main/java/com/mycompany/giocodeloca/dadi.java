/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.mycompany.giocodeloca;

import javax.swing.*;
import java.util.Random;

public class dadi {
    
    private ImageIcon[] dadoImmagini;
    private ImageIcon image;
    private int faccia;
    Random random = new Random();
    private String imagePath; 
    
    
    public dadi() {
        dadoImmagini = new ImageIcon[6];
        image= new ImageIcon("immagini/faccia1.jpg");
        for(int i = 0; i<(dadoImmagini.length); i++){
            imagePath = "immagini/faccia" + (i+1) + ".jpg";
            dadoImmagini[i] = new ImageIcon(imagePath);
        }
    }

    public void generazione(){
        faccia = random.nextInt(0,5) + 1;
        image =  dadoImmagini[faccia-1];
    }

    public ImageIcon getDado(int indice) {
        return dadoImmagini[indice];
    }

    
    public int getFaccia() {
        return faccia;
    }

    public ImageIcon getImmagine() {
        return image;
    }

    
}
