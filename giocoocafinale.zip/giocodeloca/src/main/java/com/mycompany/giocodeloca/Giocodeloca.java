/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.giocodeloca;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Giocodeloca {

    public static void main(String[] args) {
        new frame();
  
    }
}
